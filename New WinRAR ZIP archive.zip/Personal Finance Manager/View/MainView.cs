﻿using Personal_Finance_Manager.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Personal_Finance_Manager.View
{
    public partial class MainView : System.Windows.Window
    {
        public MainView(MainViewModel vm)
        {
            InitializeComponent();
            DataContext = vm;
        }
    }
}
